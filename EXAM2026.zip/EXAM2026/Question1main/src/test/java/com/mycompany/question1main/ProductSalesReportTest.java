/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.question1main;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the RentalReport class.
 */
public class ProductSalesReportTest {

    private final ProductSalesReport report = new ProductSalesReport();

    private final int[][] monthlySales = {
            {25, 18, 20}, 
            {15, 10, 12},
            {18, 15, 20}
        };

    @Test
    public void calculateTotalmonthlySalesReturnsCorrectTotal() {
       
        assertEquals(880, report.calculateTotal(monthlySales));
    }

    @Test
    public void calculatemonthlySaleReturnsCorrectAverage() {
       
        assertEquals(146.6666667, report.calculateAverage(monthlySales), 0.001);
    }

    private void assertEquals(double d, Object[] calculateAverage, double d0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
