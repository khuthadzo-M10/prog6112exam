/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author cutym
 */
 //Implements the product sales calculations required
public class Product implements IProduct {

   
    @Override
    public int calculateTotal(int[][] monthlySales) {
        validateSales(monthlySales);

        int total = 0;

        // Add all Sales values in the two-dimensional array
        for (int[] month : monthlySales) {
            for (int sale : month) {
                total += sale;
            }
        }
        return total;
    }

    
     // Calculates the average of all sales entries.
    
    @Override
    public double AverageSales(int[][] monthlySales) {
        validateSales(monthlySales);

        int numberOfEntries = 0;

        // Count the number of sales values in all rows.
        for (int[] month : monthlySales) {
            numberOfEntries += month.length;
        }

        // Count every product record in the array.
        for (int[] month : monthlySales) {
            numberOfEntries += month.length;
        }

        // Avoid division by zero if an empty array is supplied.
        return numberOfEntries == 0 ? 0 : (double) total / numberOfEntries;
    }

    @Override
    public int calculateHighest(int[][] monthlySales) {
        int highest = Integer.MIN_VALUE;

        // Compare each value to find the highest Product Sold figure.
        for (int[] month : monthlySales) {
            for (int monthlySale : month) {
                if (monthlySale > highest) {
                    highest = monthlySale;
                }
           
            }
        }
        return highest;
    }
}