/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author cutym
 */
public class PrintProduct {
    
}
public static void main(String[] args) {
    
        // A one-dimensional array stores the Month and products for the report.
        String[] products = {"Cozy Nights Mornarch mattress", "Restonic Bardos Mattress", "Sealy Phuket mattress"};
        String[] months = {"Month 1", "Month 2","Month 3"};

        // A two-dimensional array stores each year's sales by month.
        int[][] monthlySales = {
            {25, 18, 20}, 
            {15, 10, 12},
            {18, 15, 20}
        };
       // Create the calculation class and obtain the report values.
        ProductSalesReport report = new ProductSalesReport();
      
  // Display the calculated report.
        System.out.println("----------------------------------------");
        System.out.println("Total ProductSold: " + report.calculateTotal(monthlySales));
        System.out.printf("Average Bookings: %.2f%n", report.calculateAverage(monthlySales));
        System.out.println("Highest Bookings: " + report.calculateHighest(monthlySales));
        System.out.println("Most popular product: " + report.calculateHighest(monthlySales));
        System.out.println("========================================");
    }

