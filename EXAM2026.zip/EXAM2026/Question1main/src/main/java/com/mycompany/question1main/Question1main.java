/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question1main;

/**
 *
 * @author cutym
 */
public class Question1main {

public static void main(String[] args) {

        // A one-dimensional array stores the Month and products for the report.
        String[] products = {"Cozy Nights Mornarch mattress", "Restonic Bardos Mattress", "Sealy Phuket mattress"};
        String[] months = {"Month 1", "Month 2","Month 3"};

        // A two-dimensional array stores each year's sales by month.
        int[][] monthlySales = {
            {25, 18, 20}, 
            {15, 10, 12},
            {18, 15, 20}
        };

        // Create the calculation class and obtain the report values.
        ProductSalesReport report = new ProductSalesReport();

        System.out.println("========================================");
        System.out.println("       PRODUCTS SOLD REPORT");
        System.out.println("========================================");

        // Display the original SALES data.
        System.out.printf("%-12s %-10s %-10s %-10s%n",
                "Month", products[0],
                products[1], products[2]);

        for (int row = 0; row < monthlySales.length; row++) {
            System.out.printf("%-12s", "Month " + (row + 1));

            // Display each Product sales for this month.
            for (int value : monthlySales[row]) {
                System.out.printf("%-10d", value);
            }
            System.out.println();
        }

        // Display the calculated report.
        System.out.println("----------------------------------------");
        System.out.println("Total ProductSold: " + report.calculateTotal(monthlySales));
        System.out.printf("Average Bookings: %.2f%n", report.calculateAverage(monthlySales));
        System.out.println("Highest Bookings: " + report.calculateHighest(monthlySales));
        System.out.println("Most popular product: " + report.calculateHighest(monthlySales));
        System.out.println("========================================");
    }
}

