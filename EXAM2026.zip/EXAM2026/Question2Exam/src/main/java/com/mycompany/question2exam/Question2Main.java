/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question2exam;

/**
 *
 * @author cutym
 */
import javax.swing.SwingUtilities;

/**
 * Starts the Question 2 Swing application on the Event Dispatch Thread.
 */
public class Question2Main {

    public static void main(String[] args) {

        // Swing components should be created on the Event Dispatch Thread.
        SwingUtilities.invokeLater(() -> {
            ProductSalesGUI gui = new ProductSalesGUI();

            // Make the application window visible to the user.
            gui.setVisible(true);
        });
    }
}
