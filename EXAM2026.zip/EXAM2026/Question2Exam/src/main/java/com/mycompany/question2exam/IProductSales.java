/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.question2exam;

/**
 *
 * @author cutym
 */
public interface IProductSales {

    // Returns the product sales data stored in memory.
    String [][] CustomerName();

    // Returns the sum of all product sales.
    String ProductName();

    // Returns how many sales entries are strictly above the sales limit.
    int VatAmount();

    // Returns how many sales entries are strictly below the sales limit.
    int CommissionAmount();

    // Returns the number of years represented by the sales data.
    int TotalSalesAmount();
}